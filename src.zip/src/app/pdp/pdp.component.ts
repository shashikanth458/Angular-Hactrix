import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pdp',
  templateUrl: './pdp.component.html',
  styleUrls: ['./pdp.component.less']
})
export class PdpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
